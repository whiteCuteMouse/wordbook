import React from "react"
import ReactDOM from "react-dom"
import SelectableDataTable from "./SelectableDataTable"

ReactDOM.render(<SelectableDataTable />, document.getElementById("root"))
